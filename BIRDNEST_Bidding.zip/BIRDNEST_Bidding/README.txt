To run this code:

IAT as only feature is the A-series algorithms (1)
IAT and Response Time as features is the B-series algorithms (2)

To run the main function you can just run
(1) A_main.py
(2) B_main.py

To calculate AUC of each algorithm:
(1) A_Accuracy.py
(2) B_Accuracy.py

For runtime and scalability
(2) B_timing.py
